Graphviz's dot language Python interface.

This module provides with a full interface to
create handle modify and process graphs in
Graphviz's dot language.

References:

pydot Homepage: https://github.com/erocarrera/pydot
Graphviz:       http://www.graphviz.org/
DOT Language:   http://www.graphviz.org/doc/info/lang.html

Copyright (c) 2005-2011 Ero Carrera <ero.carrera@gmail.com>

Distributed under MIT license
[http://opensource.org/licenses/mit-license.html].


